
        # self.num1 = QPushButton("1",self)
        # self.num1.setFont(QFont("Times New Roman",))


        # start_x = 50
        # start_y = 180
        # button_width = 56
        # button_height = 56
        # button_spacing = 15

        # for i in range(6):
        #     for j in range(6):
        #         button = QPushButton(self)
        #         button.setGeometry(start_x + (button_width + button_spacing) * j,
        #                            start_y + (button_height + button_spacing) * i,
        #                            button_width,
        #                            button_height)
        #         number = str(i * 6 + j + 1)
        #         button.setText(number)
        #         button.setStyleSheet("""background-color:rgb(255,150,200);
        #                                 border-radius: 28px;
        #                                 border-color: rgb(102,0,50);
        #                                 border-width: 3px;
        #                                 border-style: solid;
        #                              """)
        #         button.setFont(QFont("Times New Roman",24))
        #         button.clicked.connect(lambda _, num = number: self.append_number(num))